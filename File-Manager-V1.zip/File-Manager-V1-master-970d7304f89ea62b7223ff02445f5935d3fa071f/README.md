
Made by: Julian Kragt en Justin Klerk.

Download de File-Magager-V1 en zet de index.php en fileicons in je htdocs map/folder.

In de Nav bar kan je dit:
Add file        -   Maak je eigen file aan (er moet een extention aan toegevoegt worden).
Add folder      -   Maak je eigen folder aan (er word automatisch deze index.php aan toegevoegt).
Upload file     -   Kan je meerdere files tegelijke tijd uploaden.
Clone           -   Clone je git (Public git hoef je niet je username en password toetevoegen).
Pull            -   Pull werkt in de map waar je in zit.
Push            -   Push werkt in de map waar je in zit.

Files hebben deze 2 functies:
Rename          -   Rename van je file (je moet extentions toevoegen)
Delete          -   Gewoon het verwijderen van je bestand.

Folders hebben veel meer functies:
Rename          -   Rename van je folder.
Pull            -   Pull je alleen die folder (als je die kan pullen).
Push            -   Push je alleen die folder (als je die kan pushen).
Add FM          -   Als je gecloned of op een andere manier een folder hebt toegevoegt staat daar niet de index.php in, dus met deze knop zet je de index.php in de folder.
Delete          -   Het verwijderen van de map en alles wat er is staat.

Als je nog iets hebt wat verbeterd kan worden laat het ons weten.